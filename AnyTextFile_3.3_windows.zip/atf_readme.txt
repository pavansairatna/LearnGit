anytextfile_3.3
http://sourceforge.net/projects/anytextfile

programmer: Aleksandar Josifoski
email: josifoski@gmail.com
twitter: @adam222up
http://some-traveller-somewhere.blogspot.com

programming platform: lazarus
licence: gpl
2014 august

shortcuts: (when button next is focused)
Left key or k : Previous sentence
Right key or j : Next sentence
h : Hide all buttons except next
s:  Show all buttons

.txt file should be in format starting with
$$$ for chapters 
<atf> for splitting paragraphs
You may see example in file "example_atf.txt"

when using Paste text, first line automatically will be $$$
then <atf> will be inserted on every first empty line,
other following empty lines will be deleted, prepared text will
be stored in tempatf.txt
You can use Paste text option for preparing atf text files, manually
add $$$ before  chapters, also for directly reading some pasted text
from electronic book or via inininternet. 

For receiving news on updates and discussion
can follow my twitter account (I don't post often)

If you like spiritual christian reading, this program 
Create parallel Bible translations (also made by me)
can be very usefull for creating suitable text files
http://sourceforge.net/projects/printcrippledbi/

To minimize program in systemtray click on trayicon
or click closebutton

To end program right click on systemtray icon
and click Exit or File/Exit

